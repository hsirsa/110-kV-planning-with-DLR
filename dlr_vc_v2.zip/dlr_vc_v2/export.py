﻿import os

import pandas as pd


def export_result_with_names(csv_path, meta, name_column, index_label, value_column, output_path):
    df = pd.read_csv(csv_path, sep=";", decimal=".", index_col=0)
    df.index.name = "time_step"
    df.columns = [int(col) for col in df.columns]
    meta_export = meta.copy()
    meta_export[index_label] = meta_export.index
    meta_export[name_column] = meta_export[name_column].fillna("").astype(str)
    long_df = df.reset_index().melt(id_vars=["time_step"], var_name=index_label, value_name=value_column)
    merged = long_df.merge(meta_export[[index_label, name_column]], on=index_label, how="left")
    merged = merged[["time_step", index_label, name_column, value_column]]
    merged.to_csv(output_path, index=False)


def export_named_results(net, output_path):
    export_result_with_names(
        os.path.join(output_path, "res_bus", "vm_pu.csv"),
        net.bus,
        "name",
        "bus_index",
        "vm_pu",
        os.path.join(output_path, "bus_vm_pu_named.csv"),
    )
    export_result_with_names(
        os.path.join(output_path, "res_line", "i_ka.csv"),
        net.line,
        "name",
        "line_index",
        "i_ka",
        os.path.join(output_path, "line_i_ka_named.csv"),
    )
    export_result_with_names(
        os.path.join(output_path, "res_line", "loading_percent.csv"),
        net.line,
        "name",
        "line_index",
        "loading_percent",
        os.path.join(output_path, "line_loading_percent_named.csv"),
    )
    export_result_with_names(
        os.path.join(output_path, "res_trafo", "loading_percent.csv"),
        net.trafo,
        "name",
        "trafo_index",
        "loading_percent",
        os.path.join(output_path, "trafo_loading_percent_named.csv"),
    )


def validate_nonzero_exported_results(output_path):
    exported_checks = [
        ("voltages", os.path.join(output_path, "bus_vm_pu_named.csv"), "vm_pu"),
        ("currents", os.path.join(output_path, "line_i_ka_named.csv"), "i_ka"),
        ("line loading", os.path.join(output_path, "line_loading_percent_named.csv"), "loading_percent"),
        ("transformer loading", os.path.join(output_path, "trafo_loading_percent_named.csv"), "loading_percent"),
    ]
    failed_checks = []
    for label, csv_path, value_column in exported_checks:
        if not os.path.exists(csv_path):
            raise RuntimeError(f"Post-simulation validation failed: missing exported {label} file: {csv_path}")
        df = pd.read_csv(csv_path)
        if value_column not in df.columns:
            raise RuntimeError(
                f"Post-simulation validation failed: exported {label} file lacks '{value_column}': {csv_path}"
            )
        values = pd.to_numeric(df[value_column], errors="coerce").dropna()
        if values.empty or (values.abs() <= 1e-12).all():
            failed_checks.append(label)
    if failed_checks:
        raise RuntimeError(
            "Post-simulation validation failed: all exported "
            + ", ".join(failed_checks)
            + " values are zero. This indicates a failed simulation, not a valid electrical result."
        )


def filter_named_results(csv_path, index_label, allowed_indices):
    if not allowed_indices:
        return pd.DataFrame()
    df = pd.read_csv(csv_path)
    return df[df[index_label].isin(allowed_indices)].copy()

